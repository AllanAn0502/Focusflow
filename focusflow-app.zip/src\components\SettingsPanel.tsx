import { useState, useEffect } from 'react';
import { Key, Server, Cpu, Save, Check, AlertCircle } from 'lucide-react';
import { AIProvider, AISettings } from '../types';
import { loadAISettings, saveAISettings, applyProviderDefaults, DEFAULT_SETTINGS } from '../utils/aiConfig';

interface SettingsPanelProps {
  onSaved?: () => void;
}

export function SettingsPanel({ onSaved }: SettingsPanelProps) {
  const [settings, setSettings] = useState<AISettings>(loadAISettings());
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    setSettings(loadAISettings());
  }, []);

  const handleProviderChange = (provider: AIProvider) => {
    setSettings((prev) => applyProviderDefaults(prev, provider));
  };

  const handleSave = () => {
    saveAISettings({ ...settings, enabled: !!settings.apiKey });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
    onSaved?.();
  };

  const providers: { id: AIProvider; name: string; desc: string }[] = [
    { id: 'doubao', name: '火山引擎豆包', desc: '国内模型，推荐 doubao-pro-32k' },
    { id: 'deepseek', name: 'DeepSeek', desc: '高性价比中文大模型' },
    { id: 'openai-compatible', name: 'OpenAI 兼容', desc: '任何兼容 OpenAI 格式的 API' },
  ];

  return (
    <div className="glass-card space-y-6 p-6 sm:p-8">
      <div>
        <h3 className="section-title mb-1">AI 设置</h3>
        <p className="text-sm text-surface-500 dark:text-surface-400">
          配置大模型 API 以获得更智能的任务分析。未配置时将自动使用本地规则。
        </p>
      </div>

      <div className="space-y-3">
        <label className="text-sm font-semibold text-surface-700 dark:text-surface-300">选择服务商</label>
        <div className="grid gap-3 sm:grid-cols-3">
          {providers.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => handleProviderChange(p.id)}
              className={`rounded-2xl border p-4 text-left transition-all ${
                settings.provider === p.id
                  ? 'border-primary-500 bg-primary-50 shadow dark:bg-primary-900/20'
                  : 'border-surface-200 bg-white hover:border-primary-300 dark:border-surface-800 dark:bg-surface-900 dark:hover:border-surface-700'
              }`}
            >
              <p className={`font-semibold ${settings.provider === p.id ? 'text-primary-700 dark:text-primary-300' : 'text-surface-900 dark:text-white'}`}>
                {p.name}
              </p>
              <p className="mt-1 text-xs text-surface-500 dark:text-surface-400">{p.desc}</p>
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        <div>
          <label className="mb-2 flex items-center gap-2 text-sm font-semibold text-surface-700 dark:text-surface-300">
            <Key className="h-4 w-4" />
            API Key
          </label>
          <input
            type="password"
            value={settings.apiKey}
            onChange={(e) => setSettings({ ...settings, apiKey: e.target.value })}
            placeholder={`${DEFAULT_SETTINGS[settings.provider].model} 的 API Key`}
            className="input-field"
          />
          <p className="mt-1.5 text-xs text-surface-500 dark:text-surface-400">
            API Key 仅存储在本地浏览器中，不会上传到任何服务器。
          </p>
        </div>

        <div>
          <label className="mb-2 flex items-center gap-2 text-sm font-semibold text-surface-700 dark:text-surface-300">
            <Server className="h-4 w-4" />
            Base URL
          </label>
          <input
            type="text"
            value={settings.baseUrl}
            onChange={(e) => setSettings({ ...settings, baseUrl: e.target.value })}
            placeholder="https://..."
            className="input-field"
          />
        </div>

        <div>
          <label className="mb-2 flex items-center gap-2 text-sm font-semibold text-surface-700 dark:text-surface-300">
            <Cpu className="h-4 w-4" />
            模型名称
          </label>
          <input
            type="text"
            value={settings.model}
            onChange={(e) => setSettings({ ...settings, model: e.target.value })}
            placeholder="模型 ID"
            className="input-field"
          />
        </div>
      </div>

      <div className="rounded-2xl border border-yellow-200 bg-yellow-50 p-4 dark:border-yellow-900/50 dark:bg-yellow-900/20">
        <div className="flex items-start gap-3">
          <AlertCircle className="mt-0.5 h-5 w-5 flex-shrink-0 text-yellow-600 dark:text-yellow-400" />
          <div className="text-sm text-yellow-800 dark:text-yellow-200">
            <p className="font-semibold">配置提示</p>
            <ul className="mt-1 list-inside list-disc space-y-1 text-xs">
              <li>豆包：在火山引擎方舟平台创建 API Key 并开通模型。</li>
              <li>DeepSeek：使用 DeepSeek 开放平台获取 API Key。</li>
              <li>OpenAI 兼容：支持任何与 /chat/completions 兼容的接口。</li>
            </ul>
          </div>
        </div>
      </div>

      <button onClick={handleSave} className="btn-primary w-full">
        {saved ? (
          <>
            <Check className="h-5 w-5" />
            已保存
          </>
        ) : (
          <>
            <Save className="h-5 w-5" />
            保存设置
          </>
        )}
      </button>
    </div>
  );
}
