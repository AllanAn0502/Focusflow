import { AIProvider, AISettings } from '../types';

const SETTINGS_KEY = 'focusflow_ai_settings';

export const DEFAULT_SETTINGS: Record<AIProvider, Omit<AISettings, 'enabled' | 'apiKey'>> = {
  doubao: {
    provider: 'doubao',
    baseUrl: 'https://ark.cn-beijing.volces.com/api/v3',
    model: 'doubao-pro-32k',
  },
  deepseek: {
    provider: 'deepseek',
    baseUrl: 'https://api.deepseek.com/v1',
    model: 'deepseek-chat',
  },
  'openai-compatible': {
    provider: 'openai-compatible',
    baseUrl: 'https://api.openai.com/v1',
    model: 'gpt-3.5-turbo',
  },
};

export function loadAISettings(): AISettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) {
      return {
        ...DEFAULT_SETTINGS['openai-compatible'],
        apiKey: import.meta.env.VITE_OPENAI_API_KEY || '',
        enabled: !!import.meta.env.VITE_OPENAI_API_KEY,
      };
    }
    const parsed = JSON.parse(raw) as AISettings;
    return {
      provider: parsed.provider || 'openai-compatible',
      apiKey: parsed.apiKey || '',
      baseUrl: parsed.baseUrl || DEFAULT_SETTINGS['openai-compatible'].baseUrl,
      model: parsed.model || DEFAULT_SETTINGS['openai-compatible'].model,
      enabled: parsed.enabled ?? false,
    };
  } catch {
    return {
      ...DEFAULT_SETTINGS['openai-compatible'],
      apiKey: '',
      enabled: false,
    };
  }
}

export function saveAISettings(settings: AISettings): void {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
}

export function applyProviderDefaults(settings: AISettings, provider: AIProvider): AISettings {
  const defaults = DEFAULT_SETTINGS[provider];
  return {
    ...settings,
    provider,
    baseUrl: defaults.baseUrl,
    model: defaults.model,
  };
}
