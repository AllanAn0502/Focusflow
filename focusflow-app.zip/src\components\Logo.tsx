import { Brain } from 'lucide-react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
}

export function Logo({ size = 'md', showText = true }: LogoProps) {
  const sizes = {
    sm: { icon: 'h-5 w-5', container: 'h-9 w-9', text: 'text-lg' },
    md: { icon: 'h-7 w-7', container: 'h-12 w-12', text: 'text-2xl' },
    lg: { icon: 'h-9 w-9', container: 'h-16 w-16', text: 'text-3xl' },
  };

  const s = sizes[size];

  return (
    <div className="flex items-center gap-3">
      <div
        className={`${s.container} flex items-center justify-center rounded-2xl bg-gradient-to-br from-primary-500 to-accent-500 shadow-lg shadow-primary-500/25`}
      >
        <Brain className={`${s.icon} text-white`} />
      </div>
      {showText && (
        <div>
          <h1 className={`${s.text} font-extrabold tracking-tight text-surface-900 dark:text-white`}>
            Focus<span className="text-primary-600 dark:text-primary-400">Flow</span>
          </h1>
          <p className="text-xs font-medium text-surface-500 dark:text-surface-400">智能专注助手</p>
        </div>
      )}
    </div>
  );
}
