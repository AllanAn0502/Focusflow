import { useEffect, useState, useCallback } from 'react';
import { Play, Pause, RotateCcw, CheckCircle2, X, Volume2, VolumeX, Bell } from 'lucide-react';
import { AnalysisResult } from '../types';
import { noiseEngine, NOISE_OPTIONS, soundEffects } from '../utils/whiteNoise';

interface PomodoroTimerProps {
  analysis: AnalysisResult;
  task: string;
  onComplete: (actualMinutes: number) => void;
  onCancel: () => void;
}

function formatTime(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export function PomodoroTimer({ analysis, task, onComplete, onCancel }: PomodoroTimerProps) {
  const totalSeconds = analysis.recommendedMinutes * 60;
  const [timeLeft, setTimeLeft] = useState(totalSeconds);
  const [isRunning, setIsRunning] = useState(false);
  const [isFinished, setIsFinished] = useState(false);
  const [volume, setVolume] = useState(noiseEngine.getVolume());
  const [soundEnabled, setSoundEnabled] = useState(soundEffects.getEnabled());
  const [breakReminderShown, setBreakReminderShown] = useState(false);

  const startNoise = useCallback(async () => {
    try {
      await noiseEngine.play(analysis.recommendedNoise);
    } catch (e) {
      console.warn('白噪音启动失败:', e);
    }
  }, [analysis.recommendedNoise]);

  useEffect(() => {
    return () => {
      noiseEngine.stop();
    };
  }, []);

  useEffect(() => {
    if (!isRunning || timeLeft <= 0) return;

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setIsRunning(false);
          setIsFinished(true);
          soundEffects.playComplete();
          noiseEngine.fadeOut().then(() => {
            onComplete(analysis.recommendedMinutes);
          });
          return 0;
        }
        // break reminder at halfway
        if (prev === Math.floor(totalSeconds / 2) && !breakReminderShown) {
          setBreakReminderShown(true);
          soundEffects.playBreakReminder();
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isRunning, timeLeft, analysis.recommendedMinutes, onComplete, totalSeconds, breakReminderShown]);

  const handleStart = async () => {
    setIsRunning(true);
    soundEffects.playStart();
    await startNoise();
  };

  const handlePause = () => {
    setIsRunning(false);
    noiseEngine.fadeOut(800);
  };

  const handleReset = () => {
    setIsRunning(false);
    setTimeLeft(totalSeconds);
    setIsFinished(false);
    setBreakReminderShown(false);
    noiseEngine.fadeOut(800);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const v = parseFloat(e.target.value);
    setVolume(v);
    noiseEngine.setVolume(v);
  };

  const toggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    soundEffects.setEnabled(next);
  };

  const progress = ((totalSeconds - timeLeft) / totalSeconds) * 100;
  const radius = 45;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progress / 100) * circumference;
  const noiseOption = NOISE_OPTIONS.find((n) => n.id === analysis.recommendedNoise);

  if (isFinished) {
    return (
      <div className="glass-card p-8 text-center animate-scale-in">
        <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-green-100 dark:bg-green-900/30">
          <CheckCircle2 className="h-10 w-10 text-green-500" />
        </div>
        <h3 className="mb-2 text-2xl font-bold text-surface-900 dark:text-white">专注完成！</h3>
        <p className="mb-6 text-surface-700 dark:text-surface-300">
          你完成了 <span className="font-semibold text-primary-600">{analysis.recommendedMinutes}</span> 分钟的「
          {task}」专注，任务类型：{analysis.taskType}。
        </p>
        <p className="text-sm text-surface-500 dark:text-surface-400">休息一下吧，历史记录已自动保存。</p>
      </div>
    );
  }

  return (
    <div className="glass-card p-6 text-center sm:p-8 animate-scale-in">
      <div className="mb-2 flex items-center justify-between">
        <div className="text-left">
          <h3 className="text-lg font-bold text-surface-900 dark:text-white">{task}</h3>
          <p className="text-sm text-surface-500 dark:text-surface-400">
            {analysis.taskType} · 推荐 {analysis.recommendedMinutes} 分钟
          </p>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={toggleSound}
            className="flex h-9 w-9 items-center justify-center rounded-xl text-surface-400 transition hover:bg-surface-100 hover:text-surface-600 dark:hover:bg-surface-800"
            title={soundEnabled ? '关闭音效' : '开启音效'}
          >
            {soundEnabled ? <Bell className="h-5 w-5" /> : <Bell className="h-5 w-5 opacity-40" />}
          </button>
          <button
            onClick={onCancel}
            className="flex h-9 w-9 items-center justify-center rounded-xl text-surface-400 transition hover:bg-surface-100 hover:text-surface-600 dark:hover:bg-surface-800"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
      </div>

      <div className="relative mx-auto mb-8 flex h-72 w-72 items-center justify-center sm:h-80 sm:w-80">
        <svg className="absolute inset-0 h-full w-full -rotate-90" viewBox="0 0 100 100">
          <circle
            cx="50"
            cy="50"
            r={radius}
            fill="none"
            stroke="currentColor"
            strokeWidth="6"
            className="text-surface-200 dark:text-surface-800"
          />
          <circle
            cx="50"
            cy="50"
            r={radius}
            fill="none"
            stroke="url(#gradient)"
            strokeWidth="6"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            className="transition-all duration-1000 ease-linear"
          />
          <defs>
            <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#3b82f6" />
              <stop offset="100%" stopColor="#d946ef" />
            </linearGradient>
          </defs>
        </svg>
        {/* Breathing rings */}
        {isRunning && (
          <>
            <span className="absolute inset-0 rounded-full border border-primary-400/30 animate-breath-ring" />
            <span className="absolute inset-4 rounded-full border border-accent-400/20 animate-breath-ring-delay" />
          </>
        )}
        <div className="z-10 flex flex-col items-center">
          <span
            className={`text-6xl font-bold tabular-nums tracking-tight transition-colors sm:text-7xl ${
              isRunning ? 'text-transparent bg-clip-text bg-gradient-to-r from-primary-600 to-accent-500' : 'text-surface-800 dark:text-surface-100'
            }`}
          >
            {formatTime(timeLeft)}
          </span>
          <span className="mt-2 text-sm font-medium text-surface-500 dark:text-surface-400">
            {isRunning ? '专注中...' : '准备开始'}
          </span>
        </div>
      </div>

      <div className="mb-6 flex flex-wrap items-center justify-center gap-4 text-sm text-surface-600 dark:text-surface-400">
        <div className="flex items-center gap-2">
          <Volume2 className="h-4 w-4" />
          <span className="text-xs">{noiseOption?.icon} {noiseOption?.name}</span>
          <input
            type="range"
            min={0}
            max={1}
            step={0.01}
            value={volume}
            onChange={handleVolumeChange}
            className="ml-2 h-1.5 w-24 cursor-pointer appearance-none rounded-full bg-surface-200 accent-primary-600 dark:bg-surface-700"
          />
          <span className="w-8 text-xs">{Math.round(volume * 100)}%</span>
        </div>
        <button
          onClick={toggleSound}
          className="flex items-center gap-1.5 rounded-full bg-surface-100 px-3 py-1 text-xs transition hover:bg-surface-200 dark:bg-surface-800 dark:hover:bg-surface-700"
        >
          {soundEnabled ? <Volume2 className="h-3.5 w-3.5" /> : <VolumeX className="h-3.5 w-3.5" />}
          {soundEnabled ? '音效开启' : '音效关闭'}
        </button>
      </div>

      <div className="flex flex-wrap justify-center gap-3">
        {isRunning ? (
          <button onClick={handlePause} className="btn-primary min-w-[120px] bg-yellow-500 shadow-yellow-500/25 hover:bg-yellow-600 ripple">
            <Pause className="h-5 w-5" />
            暂停
          </button>
        ) : (
          <button onClick={handleStart} className="btn-primary min-w-[120px] ripple">
            <Play className="h-5 w-5" />
            开始
          </button>
        )}
        <button onClick={handleReset} className="btn-secondary min-w-[120px] ripple">
          <RotateCcw className="h-5 w-5" />
          重置
        </button>
      </div>
    </div>
  );
}
