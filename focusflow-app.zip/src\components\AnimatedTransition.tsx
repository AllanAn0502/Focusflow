import { useEffect, useState, ReactNode } from 'react';

interface AnimatedTransitionProps {
  children: ReactNode;
  keyName: string;
  className?: string;
}

export function AnimatedTransition({ children, keyName, className = '' }: AnimatedTransitionProps) {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(false);
    const timer = setTimeout(() => setMounted(true), 30);
    return () => clearTimeout(timer);
  }, [keyName]);

  return (
    <div
      className={`transition-all duration-500 ease-out ${
        mounted ? 'translate-y-0 opacity-100' : 'translate-y-6 opacity-0'
      } ${className}`}
    >
      {children}
    </div>
  );
}
