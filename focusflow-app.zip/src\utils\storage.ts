import { FocusSession } from '../types';

const STORAGE_KEY = 'focusflow_history';

export function loadHistory(): FocusSession[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as FocusSession[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveHistory(history: FocusSession[]): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(history));
}

export function addSession(session: FocusSession): void {
  const history = loadHistory();
  history.unshift(session);
  saveHistory(history);
}

export function clearHistory(): void {
  localStorage.removeItem(STORAGE_KEY);
}

export function removeSession(id: string): void {
  const history = loadHistory().filter((s) => s.id !== id);
  saveHistory(history);
}
