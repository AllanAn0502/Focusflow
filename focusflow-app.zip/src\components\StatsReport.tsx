import { useMemo, useState } from 'react';
import { BarChart3, Calendar, Flame, Lightbulb, Clock, Target, Rocket, ArrowRight } from 'lucide-react';
import { FocusSession, TaskType } from '../types';
import {
  getTodaySessions,
  getWeekSessions,
  getMonthSessions,
  totalMinutes,
  taskTypeDistribution,
  dailyDistribution,
  hourlyDistribution,
  calculateStreak,
  generateEfficiencyAdvice,
} from '../utils/stats';

interface StatsReportProps {
  sessions: FocusSession[];
  onGoFocus?: () => void;
}

type Period = 'today' | 'week' | 'month';

const TASK_COLORS: Record<TaskType, string> = {
  '记忆': '#3b82f6',
  '理解': '#10b981',
  '创作': '#d946ef',
  '刷题': '#f59e0b',
  '其他': '#94a3b8',
};

const EXAMPLE_SESSIONS: FocusSession[] = [
  { id: 'e1', task: '背诵英语单词', taskType: '记忆', plannedMinutes: 20, actualMinutes: 20, completedAt: new Date(Date.now() - 86400000).toISOString(), noise: 'rain' },
  { id: 'e2', task: '阅读专业书籍', taskType: '理解', plannedMinutes: 35, actualMinutes: 35, completedAt: new Date(Date.now() - 86400000 * 2).toISOString(), noise: 'library' },
  { id: 'e3', task: '写项目报告', taskType: '创作', plannedMinutes: 50, actualMinutes: 45, completedAt: new Date(Date.now() - 86400000 * 3).toISOString(), noise: 'cafe' },
  { id: 'e4', task: '刷算法题', taskType: '刷题', plannedMinutes: 45, actualMinutes: 45, completedAt: new Date(Date.now() - 86400000 * 4).toISOString(), noise: 'ocean' },
  { id: 'e5', task: '整理笔记', taskType: '其他', plannedMinutes: 25, actualMinutes: 25, completedAt: new Date(Date.now() - 86400000 * 5).toISOString(), noise: 'forest' },
];

export function StatsReport({ sessions, onGoFocus }: StatsReportProps) {
  const [period, setPeriod] = useState<Period>('week');
  const [showExample, setShowExample] = useState(false);

  const filteredSessions = useMemo(() => {
    const base = showExample ? EXAMPLE_SESSIONS : sessions;
    switch (period) {
      case 'today':
        return getTodaySessions(base);
      case 'week':
        return getWeekSessions(base);
      case 'month':
        return getMonthSessions(base);
    }
  }, [sessions, period, showExample]);

  const minutes = totalMinutes(filteredSessions);
  const streak = calculateStreak(showExample ? EXAMPLE_SESSIONS : sessions);
  const advice = generateEfficiencyAdvice(filteredSessions);
  const dist = taskTypeDistribution(filteredSessions);
  const daily = dailyDistribution(filteredSessions, period === 'month' ? 30 : 7);
  const hourly = hourlyDistribution(filteredSessions);

  const maxDaily = Math.max(...daily.map((d) => d.totalMinutes), 1);
  const maxHourly = Math.max(...hourly, 1);

  const hasData = filteredSessions.length > 0;

  const renderBarChart = (isExample = false) => {
    const barCount = daily.length;
    const chartWidth = 100;
    const chartHeight = 120;
    const barWidth = chartWidth / barCount - 1;

    return (
      <svg viewBox={`0 0 ${chartWidth} ${chartHeight}`} className="h-48 w-full overflow-visible">
        {daily.map((d, i) => {
          const barHeight = (d.totalMinutes / maxDaily) * (chartHeight - 20);
          const x = i * (barWidth + 1);
          const y = chartHeight - barHeight;
          const label = period === 'month' ? d.date.slice(8, 10) : d.date.slice(5, 10);
          const showLabel = period === 'month' ? i % 5 === 0 : true;

          return (
            <g key={d.date} className={`${isExample ? 'opacity-50' : ''} chart-bar-enter`} style={{ animationDelay: `${i * 40}ms` }}>
              <rect
                x={x}
                y={y}
                width={barWidth}
                height={barHeight}
                rx={2}
                className="fill-primary-500 transition-all hover:fill-primary-400"
              />
              {showLabel && (
                <text
                  x={x + barWidth / 2}
                  y={chartHeight - 4}
                  textAnchor="middle"
                  className="fill-surface-500 text-[6px] dark:fill-surface-400"
                >
                  {label}
                </text>
              )}
            </g>
          );
        })}
      </svg>
    );
  };

  const renderHourlyChart = (isExample = false) => {
    const barCount = 24;
    const chartWidth = 100;
    const chartHeight = 80;
    const barWidth = chartWidth / barCount - 0.5;

    return (
      <svg viewBox={`0 0 ${chartWidth} ${chartHeight}`} className="h-36 w-full overflow-visible">
        {hourly.map((value, i) => {
          const barHeight = (value / maxHourly) * (chartHeight - 16);
          const x = i * (barWidth + 0.5);
          const y = chartHeight - barHeight;

          return (
            <g key={i} className={`${isExample ? 'opacity-50' : ''} chart-bar-enter`} style={{ animationDelay: `${i * 15}ms` }}>
              <rect
                x={x}
                y={y}
                width={barWidth}
                height={barHeight}
                rx={1}
                className="fill-accent-500 transition-all hover:fill-accent-400"
              />
              {i % 4 === 0 && (
                <text
                  x={x + barWidth / 2}
                  y={chartHeight - 2}
                  textAnchor="middle"
                  className="fill-surface-500 text-[5px] dark:fill-surface-400"
                >
                  {i}h
                </text>
              )}
            </g>
          );
        })}
      </svg>
    );
  };

  const renderPieChart = (isExample = false) => {
    const entries = Object.entries(dist).filter(([, v]) => v > 0);
    const total = entries.reduce((sum, [, v]) => sum + v, 0);
    if (total === 0) return null;

    let cumulative = 0;
    const radius = 16;
    const circumference = 2 * Math.PI * radius;

    return (
      <div className={`flex items-center gap-6 ${isExample ? 'opacity-50' : ''}`}>
        <svg viewBox="0 0 40 40" className="h-32 w-32 -rotate-90">
          {entries.map(([type, value], i) => {
            const portion = value / total;
            const dash = portion * circumference;
            const offset = -cumulative * circumference;
            cumulative += portion;
            return (
              <circle
                key={type}
                cx="20"
                cy="20"
                r={radius}
                fill="none"
                stroke={TASK_COLORS[type as TaskType]}
                strokeWidth="6"
                strokeDasharray={`${dash} ${circumference - dash}`}
                strokeDashoffset={offset}
                className="chart-segment-enter"
                style={{ animationDelay: `${i * 80}ms` }}
              />
            );
          })}
        </svg>
        <div className="space-y-2">
          {entries.map(([type, value]) => (
            <div key={type} className="flex items-center gap-2 text-sm">
              <span
                className="h-3 w-3 rounded-full"
                style={{ backgroundColor: TASK_COLORS[type as TaskType] }}
              />
              <span className="text-surface-700 dark:text-surface-300">{type}</span>
              <span className="text-xs text-surface-500">{Math.round((value / total) * 100)}%</span>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const StatCard = ({
    icon: Icon,
    label,
    value,
    sub,
    isExample,
  }: {
    icon: typeof Clock;
    label: string;
    value: string;
    sub?: string;
    isExample?: boolean;
  }) => (
    <div className={`rounded-2xl bg-surface-50 p-4 transition hover:bg-surface-100 dark:bg-surface-800/50 dark:hover:bg-surface-800 ${isExample ? 'opacity-50' : ''}`}>
      <div className="mb-2 flex items-center gap-2 text-surface-500 dark:text-surface-400">
        <Icon className="h-4 w-4" />
        <span className="text-xs font-medium">{label}</span>
      </div>
      <p className="text-2xl font-bold text-surface-900 dark:text-white">{value}</p>
      {sub && <p className="mt-1 text-xs text-surface-500 dark:text-surface-400">{sub}</p>}
    </div>
  );

  if (sessions.length === 0 && !showExample) {
    return (
      <div className="glass-card space-y-6 p-6 sm:p-8 animate-fade-in">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h3 className="section-title mb-1 flex items-center gap-2">
              <BarChart3 className="h-5 w-5 text-primary-600" />
              专注统计报告
            </h3>
            <p className="text-sm text-surface-500 dark:text-surface-400">用数据了解自己的专注节奏</p>
          </div>
        </div>

        <div className="flex flex-col items-center justify-center rounded-3xl border border-dashed border-surface-300 bg-surface-50/50 py-16 text-center dark:border-surface-700 dark:bg-surface-900/30">
          <div className="relative mb-6">
            <div className="flex h-24 w-24 items-center justify-center rounded-full bg-primary-100 dark:bg-primary-900/30">
              <Rocket className="h-12 w-12 text-primary-500" />
            </div>
            <span className="absolute -right-1 -top-1 flex h-8 w-8 items-center justify-center rounded-full bg-yellow-100 text-lg dark:bg-yellow-900/30">
              ✨
            </span>
          </div>
          <h4 className="mb-2 text-xl font-bold text-surface-900 dark:text-white">完成第一次专注，开始你的效率之旅</h4>
          <p className="mb-6 max-w-xs text-sm text-surface-500 dark:text-surface-400">
            每一次番茄钟都会在这里留下足迹，坚持专注，看见成长。
          </p>
          <button onClick={onGoFocus} className="btn-primary ripple">
            去专注
            <ArrowRight className="h-5 w-5" />
          </button>
        </div>

        <div className="rounded-2xl border border-dashed border-surface-300 p-4 dark:border-surface-700">
          <div className="mb-4 flex items-center justify-between">
            <p className="text-sm font-semibold text-surface-600 dark:text-surface-300">示例数据预览</p>
            <button
              onClick={() => setShowExample(true)}
              className="text-xs font-medium text-primary-600 transition hover:text-primary-700 dark:text-primary-400"
            >
              展开查看
            </button>
          </div>
          <p className="text-xs text-surface-400 dark:text-surface-500">虚线框内为演示数据，真实记录会自动替换。</p>
        </div>
      </div>
    );
  }

  const isExample = sessions.length === 0 && showExample;

  return (
    <div className="glass-card space-y-6 p-6 sm:p-8 animate-fade-in">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h3 className="section-title mb-1 flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-primary-600" />
            专注统计报告
            {isExample && (
              <span className="rounded-full bg-surface-100 px-2 py-0.5 text-xs font-medium text-surface-500 dark:bg-surface-800 dark:text-surface-400">
                示例
              </span>
            )}
          </h3>
          <p className="text-sm text-surface-500 dark:text-surface-400">用数据了解自己的专注节奏</p>
        </div>
        <div className="flex rounded-xl border border-surface-200 bg-white p-1 dark:border-surface-800 dark:bg-surface-900">
          {(['today', 'week', 'month'] as Period[]).map((p) => (
            <button
              key={p}
              onClick={() => setPeriod(p)}
              className={`rounded-lg px-3 py-1.5 text-xs font-medium transition ${
                period === p
                  ? 'bg-primary-600 text-white'
                  : 'text-surface-600 hover:bg-surface-100 dark:text-surface-400 dark:hover:bg-surface-800'
              }`}
            >
              {p === 'today' ? '今日' : p === 'week' ? '本周' : '本月'}
            </button>
          ))}
        </div>
      </div>

      {!hasData ? (
        <div className="rounded-2xl border border-dashed border-surface-300 py-12 text-center dark:border-surface-700">
          <Target className="mx-auto mb-3 h-10 w-10 text-surface-300 dark:text-surface-600" />
          <p className="text-surface-500 dark:text-surface-400">该时段暂无专注记录，去完成一个番茄钟吧！</p>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            <StatCard icon={Clock} label="专注时长" value={`${minutes} 分钟`} sub={`${filteredSessions.length} 次`} isExample={isExample} />
            <StatCard icon={Calendar} label="平均单次" value={`${Math.round(minutes / filteredSessions.length)} 分钟`} isExample={isExample} />
            <StatCard icon={Flame} label="连续专注" value={`${streak} 天`} sub="Keep it up!" isExample={isExample} />
            <StatCard icon={Target} label="完成率" value="100%" sub="太棒了" isExample={isExample} />
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            <div className="rounded-2xl border border-surface-200 bg-white p-4 dark:border-surface-800 dark:bg-surface-900">
              <p className="mb-4 text-sm font-semibold text-surface-700 dark:text-surface-300">专注时长趋势</p>
              {renderBarChart(isExample)}
            </div>

            <div className="rounded-2xl border border-surface-200 bg-white p-4 dark:border-surface-800 dark:bg-surface-900">
              <p className="mb-4 text-sm font-semibold text-surface-700 dark:text-surface-300">任务类型分布</p>
              {renderPieChart(isExample)}
            </div>
          </div>

          <div className="rounded-2xl border border-surface-200 bg-white p-4 dark:border-surface-800 dark:bg-surface-900">
            <p className="mb-4 text-sm font-semibold text-surface-700 dark:text-surface-300">专注时段分布</p>
            {renderHourlyChart(isExample)}
          </div>

          <div className="flex items-start gap-3 rounded-2xl bg-accent-50 p-4 dark:bg-accent-900/20">
            <Lightbulb className="mt-0.5 h-5 w-5 flex-shrink-0 text-accent-600 dark:text-accent-400" />
            <div>
              <p className="text-sm font-semibold text-accent-800 dark:text-accent-200">效率建议</p>
              <p className="text-sm text-accent-700 dark:text-accent-300">{advice}</p>
            </div>
          </div>

          {isExample && (
            <button
              onClick={() => setShowExample(false)}
              className="w-full rounded-xl border border-dashed border-surface-300 py-3 text-xs font-medium text-surface-500 transition hover:bg-surface-50 dark:border-surface-700 dark:hover:bg-surface-800"
            >
              关闭示例预览
            </button>
          )}
        </>
      )}
    </div>
  );
}
