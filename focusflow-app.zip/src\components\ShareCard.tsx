import { useRef, useCallback, useState, useMemo } from 'react';
import { Download, Copy, CheckCircle2, Sparkles } from 'lucide-react';
import { toPng } from 'html-to-image';
import { AnalysisResult } from '../types';
import { NOISE_OPTIONS } from '../utils/whiteNoise';

interface ShareCardProps {
  task: string;
  analysis: AnalysisResult;
  onReset: () => void;
  onViewStats: () => void;
}

export function ShareCard({ task, analysis, onReset, onViewStats }: ShareCardProps) {
  const cardRef = useRef<HTMLDivElement>(null);
  const [copied, setCopied] = useState(false);

  const encouragement = useMemo(() => {
    const list = [
      '专注当下，未来可期',
      '每一步都算数',
      '今天的你，比昨天更专注',
      '坚持就是超能力',
      '高效一小步，成长一大步',
    ];
    return list[Math.floor(Math.random() * list.length)];
  }, []);

  const dateStr = new Date().toLocaleDateString('zh-CN', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const noise = NOISE_OPTIONS.find((n) => n.id === analysis.recommendedNoise);

  const handleDownload = useCallback(async () => {
    if (!cardRef.current) return;
    try {
      const dataUrl = await toPng(cardRef.current, {
        pixelRatio: 2,
        backgroundColor: '#ffffff',
      });
      const link = document.createElement('a');
      link.download = `FocusFlow-${task.slice(0, 20)}-${Date.now()}.png`;
      link.href = dataUrl;
      link.click();
    } catch (e) {
      console.error('生成分享卡片失败:', e);
    }
  }, [task]);

  const handleCopyText = useCallback(() => {
    const text = `我在 FocusFlow 完成了「${task}」的专注\n专注时长：${analysis.recommendedMinutes} 分钟\n任务类型：${analysis.taskType}\n陪伴白噪音：${noise?.name ?? '-'}\n${encouragement}\n${dateStr}`;
    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }, [task, analysis, encouragement, dateStr, noise]);

  return (
    <div className="glass-card space-y-6 p-6 sm:p-8 animate-scale-in">
      <div className="text-center">
        <div className="mx-auto mb-4 flex h-20 w-20 animate-bounce items-center justify-center rounded-full bg-green-100 dark:bg-green-900/30">
          <CheckCircle2 className="h-10 w-10 text-green-500" />
        </div>
        <h3 className="mb-1 text-2xl font-bold text-surface-900 dark:text-white">专注完成！</h3>
        <p className="text-surface-500 dark:text-surface-400">
          你完成了 <span className="font-semibold text-primary-600">{analysis.recommendedMinutes}</span> 分钟的「
          {task}」专注
        </p>
      </div>

      <div
        ref={cardRef}
        className="relative mx-auto max-w-sm overflow-hidden rounded-3xl bg-gradient-to-br from-primary-500 to-accent-600 p-1 shadow-2xl"
      >
        <div className="rounded-[1.4rem] bg-white p-6 text-surface-900 dark:bg-surface-900 dark:text-white">
          <div className="mb-6 flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary-600 text-white">
              <Sparkles className="h-4 w-4" />
            </div>
            <span className="text-lg font-bold tracking-tight">FocusFlow</span>
          </div>

          <p className="mb-1 text-xs font-medium uppercase tracking-wider text-surface-500 dark:text-surface-400">
            今日专注
          </p>
          <h4 className="mb-4 text-2xl font-bold leading-tight">{task}</h4>

          <div className="mb-6 grid grid-cols-2 gap-3">
            <div className="rounded-2xl bg-primary-50 p-3 dark:bg-primary-900/20">
              <p className="text-xs text-primary-700 dark:text-primary-300">专注时长</p>
              <p className="text-xl font-bold text-primary-700 dark:text-primary-200">
                {analysis.recommendedMinutes} 分钟
              </p>
            </div>
            <div className="rounded-2xl bg-accent-50 p-3 dark:bg-accent-900/20">
              <p className="text-xs text-accent-700 dark:text-accent-300">任务类型</p>
              <p className="text-xl font-bold text-accent-700 dark:text-accent-200">{analysis.taskType}</p>
            </div>
          </div>

          <div className="mb-6 rounded-2xl border border-dashed border-surface-300 p-4 text-center dark:border-surface-700">
            <p className="text-sm font-medium text-surface-600 dark:text-surface-300">{encouragement}</p>
          </div>

          <div className="flex items-center justify-between text-xs text-surface-500 dark:text-surface-400">
            <span>{dateStr}</span>
            <span>{noise?.icon} {noise?.name}</span>
          </div>
        </div>
      </div>

      <div className="flex flex-col justify-center gap-3 sm:flex-row">
        <button onClick={handleDownload} className="btn-primary ripple">
          <Download className="h-5 w-5" />
          下载图片
        </button>
        <button onClick={handleCopyText} className="btn-secondary ripple">
          {copied ? <CheckCircle2 className="h-5 w-5 text-green-500" /> : <Copy className="h-5 w-5" />}
          {copied ? '已复制' : '复制文字'}
        </button>
        <button onClick={onViewStats} className="btn-secondary ripple">
          查看统计
        </button>
      </div>

      <button onClick={onReset} className="btn-secondary mx-auto flex w-full max-w-xs items-center justify-center">
        <Sparkles className="h-5 w-5" />
        再来一个
      </button>
    </div>
  );
}
