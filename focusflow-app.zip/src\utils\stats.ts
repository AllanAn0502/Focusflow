import { FocusSession, TaskType, DailyStats } from '../types';

function toISODate(d: Date): string {
  return d.toISOString().slice(0, 10);
}

function startOfDay(d: Date): Date {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate());
}

function startOfWeek(d: Date): Date {
  const day = d.getDay();
  const diff = (day === 0 ? -6 : 1) - day;
  const monday = new Date(d);
  monday.setDate(d.getDate() + diff);
  monday.setHours(0, 0, 0, 0);
  return monday;
}

function startOfMonth(d: Date): Date {
  return new Date(d.getFullYear(), d.getMonth(), 1);
}

export function getTodaySessions(sessions: FocusSession[]): FocusSession[] {
  const today = toISODate(new Date());
  return sessions.filter((s) => s.completedAt.slice(0, 10) === today);
}

export function getWeekSessions(sessions: FocusSession[]): FocusSession[] {
  const now = new Date();
  const weekStart = startOfWeek(now);
  return sessions.filter((s) => new Date(s.completedAt) >= weekStart);
}

export function getMonthSessions(sessions: FocusSession[]): FocusSession[] {
  const now = new Date();
  const monthStart = startOfMonth(now);
  return sessions.filter((s) => new Date(s.completedAt) >= monthStart);
}

export function totalMinutes(sessions: FocusSession[]): number {
  return sessions.reduce((sum, s) => sum + s.actualMinutes, 0);
}

export function taskTypeDistribution(sessions: FocusSession[]): Record<TaskType, number> {
  const dist: Record<TaskType, number> = {
    '记忆': 0,
    '理解': 0,
    '创作': 0,
    '刷题': 0,
    '其他': 0,
  };
  sessions.forEach((s) => {
    dist[s.taskType] = (dist[s.taskType] || 0) + s.actualMinutes;
  });
  return dist;
}

export function hourlyDistribution(sessions: FocusSession[]): number[] {
  const hours = new Array(24).fill(0);
  sessions.forEach((s) => {
    const hour = new Date(s.completedAt).getHours();
    hours[hour] += s.actualMinutes;
  });
  return hours;
}

export function dailyDistribution(sessions: FocusSession[], days = 7): DailyStats[] {
  const result: DailyStats[] = [];
  const today = startOfDay(new Date());
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(today.getDate() - i);
    const dateStr = toISODate(d);
    const daySessions = sessions.filter((s) => s.completedAt.slice(0, 10) === dateStr);
    result.push({
      date: dateStr,
      totalMinutes: daySessions.reduce((sum, s) => sum + s.actualMinutes, 0),
      sessionCount: daySessions.length,
    });
  }
  return result;
}

export function calculateStreak(sessions: FocusSession[]): number {
  if (sessions.length === 0) return 0;

  const uniqueDays = new Set(sessions.map((s) => s.completedAt.slice(0, 10)));
  const sortedDays = Array.from(uniqueDays).sort((a, b) => b.localeCompare(a));

  const today = toISODate(new Date());
  const yesterdayDate = new Date();
  yesterdayDate.setDate(yesterdayDate.getDate() - 1);
  const yesterday = toISODate(yesterdayDate);

  if (sortedDays[0] !== today && sortedDays[0] !== yesterday) {
    return 0;
  }

  let streak = 1;
  for (let i = 1; i < sortedDays.length; i++) {
    const prev = new Date(sortedDays[i - 1]);
    const curr = new Date(sortedDays[i]);
    const diffDays = (prev.getTime() - curr.getTime()) / (1000 * 60 * 60 * 24);
    if (diffDays === 1) {
      streak++;
    } else {
      break;
    }
  }
  return streak;
}

export function generateEfficiencyAdvice(sessions: FocusSession[]): string {
  if (sessions.length === 0) {
    return '开始你的第一次专注，数据会帮你发现最适合自己的节奏。';
  }

  const total = totalMinutes(sessions);
  const avg = total / sessions.length;
  const dist = taskTypeDistribution(sessions);
  const entries = Object.entries(dist).filter(([, v]) => v > 0);
  const topType = entries.sort((a, b) => b[1] - a[1])[0]?.[0];

  if (avg < 15) {
    return '你的单次专注时长偏短，尝试减少干扰，延长到 20 分钟以上会更高效。';
  }

  if (topType === '创作' && avg < 35) {
    return '创作类任务需要更长时间进入心流，建议单次专注 40 分钟以上。';
  }

  if (topType === '记忆' && avg > 35) {
    return '记忆类任务更适合短时高频，超过 30 分钟建议拆分并穿插复习。';
  }

  if (sessions.length >= 5 && total > 120) {
    return '你的专注习惯很好！保持稳定节奏，记得每完成一个番茄钟站起来活动一下。';
  }

  return '尝试固定时间学习，让大脑形成条件反射，效率会逐步提升。';
}
