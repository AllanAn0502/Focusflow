export type TaskType = '记忆' | '理解' | '创作' | '刷题' | '其他';

export type NoiseType =
  | 'rain'
  | 'cafe'
  | 'library'
  | 'forest'
  | 'ocean'
  | 'fire'
  | 'wind'
  | 'night'
  | 'stream'
  | 'train';

export interface NoiseOption {
  id: NoiseType;
  name: string;
  icon: string;
  description: string;
}

export type AnalysisSource = 'ai' | 'local';

export interface AnalysisResult {
  taskType: TaskType;
  recommendedMinutes: number;
  recommendedBreakMinutes: number;
  recommendedNoise: NoiseType;
  advice: string;
  reason: string;
  source?: AnalysisSource;
}

export interface FocusSession {
  id: string;
  task: string;
  taskType: TaskType;
  plannedMinutes: number;
  actualMinutes: number;
  completedAt: string;
  noise?: NoiseType;
}

export interface TimerState {
  timeLeft: number;
  totalTime: number;
  isRunning: boolean;
}

export type AIProvider = 'doubao' | 'deepseek' | 'openai-compatible';

export interface AISettings {
  provider: AIProvider;
  apiKey: string;
  baseUrl: string;
  model: string;
  enabled: boolean;
}

export interface DailyStats {
  date: string;
  totalMinutes: number;
  sessionCount: number;
}
