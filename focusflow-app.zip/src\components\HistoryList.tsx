import { FocusSession } from '../types';
import { History, Trash2, Clock, Music } from 'lucide-react';
import { NOISE_OPTIONS } from '../utils/whiteNoise';

interface HistoryListProps {
  sessions: FocusSession[];
  onClear: () => void;
}

export function HistoryList({ sessions, onClear }: HistoryListProps) {
  if (sessions.length === 0) {
    return null;
  }

  return (
    <div className="glass-card p-6 sm:p-8">
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2 text-surface-700 dark:text-surface-300">
          <History className="h-5 w-5 text-primary-600" />
          <h3 className="section-title">专注历史</h3>
        </div>
        <button
          onClick={onClear}
          className="flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-sm font-medium text-red-600 transition hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-900/20"
        >
          <Trash2 className="h-4 w-4" />
          清空
        </button>
      </div>

      <ul className="scrollbar-thin max-h-80 space-y-3 overflow-y-auto pr-1">
        {sessions.map((session) => {
          const noise = session.noise ? NOISE_OPTIONS.find((n) => n.id === session.noise) : null;
          return (
            <li
              key={session.id}
              className="flex items-center justify-between rounded-2xl border border-surface-100 bg-surface-50 p-4 transition hover:border-primary-200 hover:bg-primary-50/50 dark:border-surface-800 dark:bg-surface-900 dark:hover:border-primary-800 dark:hover:bg-primary-900/10"
            >
              <div className="min-w-0 flex-1">
                <p className="truncate font-semibold text-surface-900 dark:text-white">{session.task}</p>
                <p className="mt-0.5 flex items-center gap-2 text-xs text-surface-500 dark:text-surface-400">
                  <Clock className="h-3 w-3" />
                  {new Date(session.completedAt).toLocaleString('zh-CN')} · {session.taskType}
                  {noise && (
                    <>
                      <Music className="ml-1 h-3 w-3" />
                      {noise.name}
                    </>
                  )}
                </p>
              </div>
              <div className="ml-4 text-right">
                <p className="font-bold text-primary-600 dark:text-primary-400">{session.actualMinutes} 分钟</p>
                <p className="text-xs text-surface-500 dark:text-surface-400">计划 {session.plannedMinutes} 分钟</p>
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
