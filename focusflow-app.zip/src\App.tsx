import { useCallback, useEffect, useState } from 'react';
import { Timer, BarChart3, Settings } from 'lucide-react';
import { AnalysisResult, FocusSession, TaskType, AISettings } from './types';
import { analyzeTask } from './utils/taskAnalyzer';
import { addSession, clearHistory, loadHistory } from './utils/storage';
import { loadAISettings } from './utils/aiConfig';
import { TaskInput } from './components/TaskInput';
import { AnalysisResultView } from './components/AnalysisResult';
import { PomodoroTimer } from './components/PomodoroTimer';
import { HistoryList } from './components/HistoryList';
import { StatsReport } from './components/StatsReport';
import { SettingsPanel } from './components/SettingsPanel';
import { Logo } from './components/Logo';
import { ThemeToggle } from './components/ThemeToggle';
import { AnimatedTransition } from './components/AnimatedTransition';
import { ShareCard } from './components/ShareCard';

type AppStage = 'input' | 'analysis' | 'timer' | 'finished';
type Tab = 'focus' | 'stats' | 'settings';

function App() {
  const [activeTab, setActiveTab] = useState<Tab>('focus');
  const [stage, setStage] = useState<AppStage>('input');
  const [task, setTask] = useState('');
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState<FocusSession[]>([]);
  const [aiSettings, setAISettings] = useState<AISettings>(loadAISettings());
  const [isDark, setIsDark] = useState(() => {
    if (typeof window === 'undefined') return false;
    return localStorage.getItem('focusflow_theme') === 'dark' ||
      (!localStorage.getItem('focusflow_theme') && window.matchMedia('(prefers-color-scheme: dark)').matches);
  });

  useEffect(() => {
    setHistory(loadHistory());
  }, []);

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('focusflow_theme', isDark ? 'dark' : 'light');
  }, [isDark]);

  const handleAnalyze = useCallback(async (inputTask: string, useAI: boolean) => {
    const settings = loadAISettings();
    setLoading(true);
    setTask(inputTask);
    const result = await analyzeTask(inputTask, useAI, settings);
    setAnalysis(result);
    setStage('analysis');
    setLoading(false);
  }, []);

  const handleStartTimer = useCallback(() => {
    setStage('timer');
  }, []);

  const handleReset = useCallback(() => {
    setTask('');
    setAnalysis(null);
    setStage('input');
  }, []);

  const handleComplete = useCallback(
    (actualMinutes: number) => {
      if (!analysis) return;
      const session: FocusSession = {
        id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
        task,
        taskType: analysis.taskType as TaskType,
        plannedMinutes: analysis.recommendedMinutes,
        actualMinutes,
        completedAt: new Date().toISOString(),
        noise: analysis.recommendedNoise,
      };
      addSession(session);
      setHistory(loadHistory());
      setStage('finished');
    },
    [analysis, task]
  );

  const handleCancelTimer = useCallback(() => {
    setStage('analysis');
  }, []);

  const handleClearHistory = useCallback(() => {
    clearHistory();
    setHistory([]);
  }, []);

  const handleSettingsSaved = useCallback(() => {
    setAISettings(loadAISettings());
  }, []);

  const handleGoFocus = useCallback(() => {
    setActiveTab('focus');
    handleReset();
  }, [handleReset]);

  const renderFocusContent = () => {
    switch (stage) {
      case 'input':
        return (
          <AnimatedTransition keyName="input" className="space-y-6">
            <div className="glass-card p-6 sm:p-8">
              <TaskInput onAnalyze={handleAnalyze} loading={loading} aiEnabled={aiSettings.enabled} />
            </div>
            {history.length > 0 && (
              <div className="grid gap-4 sm:grid-cols-3">
                {[
                  { label: '今日专注', value: `${history.filter((s) => s.completedAt.slice(0, 10) === new Date().toISOString().slice(0, 10)).reduce((a, b) => a + b.actualMinutes, 0)} 分钟` },
                  { label: '累计次数', value: `${history.length} 次` },
                  { label: '最常任务', value: '查看统计' },
                ].map((stat) => (
                  <div
                    key={stat.label}
                    className="rounded-2xl border border-surface-200 bg-white p-4 text-center transition hover:border-primary-300 hover:shadow-sm dark:border-surface-800 dark:bg-surface-900"
                  >
                    <p className="text-xs text-surface-500 dark:text-surface-400">{stat.label}</p>
                    <p className="mt-1 text-xl font-bold text-surface-900 dark:text-white">{stat.value}</p>
                  </div>
                ))}
              </div>
            )}
          </AnimatedTransition>
        );
      case 'analysis':
        return analysis ? (
          <AnimatedTransition keyName="analysis">
            <AnalysisResultView result={analysis} onStart={handleStartTimer} onReset={handleReset} />
          </AnimatedTransition>
        ) : null;
      case 'timer':
        return analysis ? (
          <AnimatedTransition keyName="timer">
            <PomodoroTimer analysis={analysis} task={task} onComplete={handleComplete} onCancel={handleCancelTimer} />
          </AnimatedTransition>
        ) : null;
      case 'finished':
        return analysis ? (
          <AnimatedTransition keyName="finished">
            <ShareCard
              task={task}
              analysis={analysis}
              onReset={handleReset}
              onViewStats={() => setActiveTab('stats')}
            />
          </AnimatedTransition>
        ) : null;
    }
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'focus':
        return (
          <div className="mx-auto max-w-2xl space-y-6">
            {renderFocusContent()}
            {stage === 'input' && <HistoryList sessions={history} onClear={handleClearHistory} />}
          </div>
        );
      case 'stats':
        return (
          <div className="mx-auto max-w-4xl">
            <StatsReport sessions={history} onGoFocus={handleGoFocus} />
          </div>
        );
      case 'settings':
        return (
          <div className="mx-auto max-w-2xl">
            <SettingsPanel onSaved={handleSettingsSaved} />
          </div>
        );
    }
  };

  const tabs: { id: Tab; label: string; icon: typeof Timer }[] = [
    { id: 'focus', label: '专注', icon: Timer },
    { id: 'stats', label: '统计', icon: BarChart3 },
    { id: 'settings', label: '设置', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-surface-50 via-white to-primary-50 pb-24 transition-colors duration-300 dark:from-surface-950 dark:via-surface-900 dark:to-surface-950">
      <div className="mx-auto max-w-6xl px-4 pt-6 sm:px-6 lg:px-8">
        <header className="mb-8 flex items-center justify-between">
          <Logo />
          <ThemeToggle isDark={isDark} onToggle={() => setIsDark((d) => !d)} />
        </header>

        <main className="min-h-[60vh]" key={activeTab}>
          <AnimatedTransition keyName={activeTab} className="min-h-[60vh]">
            {renderContent()}
          </AnimatedTransition>
        </main>

        <footer className="mt-12 text-center text-xs text-surface-400 dark:text-surface-500">
          FocusFlow · 智能专注助手 · 本地规则 + AI 分析 + 白噪音
        </footer>
      </div>

      <nav className="fixed bottom-4 left-1/2 z-50 w-[calc(100%-2rem)] max-w-md -translate-x-1/2 rounded-2xl border border-surface-200 bg-white/90 p-2 shadow-lg backdrop-blur-xl transition dark:border-surface-800 dark:bg-surface-900/90">
        <div className="flex items-center justify-around">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`relative flex flex-1 flex-col items-center gap-1 rounded-xl py-2 transition-all active:scale-95 ${
                  isActive
                    ? 'text-primary-600 dark:text-primary-400'
                    : 'text-surface-500 hover:bg-surface-100 dark:text-surface-400 dark:hover:bg-surface-800'
                }`}
              >
                <Icon className="h-5 w-5 transition-transform duration-200" style={{ transform: isActive ? 'scale(1.1)' : 'scale(1)' }} />
                <span className="text-xs font-medium">{tab.label}</span>
                {isActive && (
                  <span className="absolute bottom-1 h-1 w-6 rounded-full bg-primary-600 dark:bg-primary-400" />
                )}
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}

export default App;
