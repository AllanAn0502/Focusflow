# FocusFlow

一个最小可用的智能专注 Web 应用，帮助学习者输入任务、分析任务类型并运行番茄钟。

## 技术栈

- React 18
- TypeScript 5
- Vite 5
- Tailwind CSS 3
- lucide-react（图标）

## 功能特性（MVP）

1. **任务输入**：在首页输入学习任务，例如"背诵 50 个英语单词"。
2. **智能分析**：
   - 默认使用本地关键词规则判断任务类型（记忆 / 理解 / 创作 / 刷题 / 其他）并推荐专注时长。
   - 勾选"启用 AI 分析"后可调用 OpenAI API（需配置 `VITE_OPENAI_API_KEY`），失败时自动回退到本地规则。
3. **番茄钟计时器**：支持开始、暂停、重置，环形进度条实时显示剩余时间。
4. **专注结束提示**：倒计时结束后显示完成提示并保存记录。
5. **本地历史记录**：使用 `localStorage` 保存每次专注记录，支持清空。

## 快速启动

```bash
# 进入项目目录
cd focusflow-app

# 安装依赖
npm install

# 启动开发服务器
npm run dev
```

开发服务器默认运行在 http://localhost:5173。

## 构建

```bash
npm run build
```

构建产物输出到 `dist` 目录。

## 配置 AI 分析（可选）

在项目根目录创建 `.env.local` 文件：

```env
VITE_OPENAI_API_KEY=your_openai_api_key
```

重启开发服务器后，勾选"启用 AI 分析"即可调用 OpenAI。

## 项目结构

```
focusflow-app
├── index.html
├── package.json
├── postcss.config.js
├── tailwind.config.js
├── tsconfig.json
├── vite.config.ts
└── src
    ├── App.tsx
    ├── main.tsx
    ├── index.css
    ├── types.ts
    ├── components
    │   ├── TaskInput.tsx
    │   ├── AnalysisResult.tsx
    │   ├── PomodoroTimer.tsx
    │   └── HistoryList.tsx
    └── utils
        ├── taskAnalyzer.ts
        └── storage.ts
```

## 脚本说明

- `npm run dev`：启动开发服务器
- `npm run build`：TypeScript 类型检查 + Vite 生产构建
- `npm run preview`：预览生产构建
- `npm run lint`：运行 ESLint
