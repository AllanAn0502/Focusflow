import { AnalysisResult, AnalysisSource, NoiseType, TaskType } from '../types';
import { AISettings } from '../types';

interface Rule {
  keywords: string[];
  taskType: TaskType;
  recommendedMinutes: number;
  recommendedBreakMinutes: number;
  recommendedNoise: NoiseType;
  advice: string;
  reason: string;
}

const RULES: Rule[] = [
  {
    keywords: ['背单词', '记忆', '背诵', '记', '公式', '默写', '词汇', '英语单词', '古文'],
    taskType: '记忆',
    recommendedMinutes: 20,
    recommendedBreakMinutes: 5,
    recommendedNoise: 'rain',
    advice: '短时高频是记忆的黄金法则，建议利用艾宾浩斯曲线及时复习。',
    reason: '记忆类任务适合短时高频，推荐 20 分钟番茄钟。',
  },
  {
    keywords: ['阅读', '理解', '学习', '看书', '听课', '笔记', '概念', '原理', '理论'],
    taskType: '理解',
    recommendedMinutes: 35,
    recommendedBreakMinutes: 7,
    recommendedNoise: 'library',
    advice: '遇到难点先自己思考，再查阅资料，最后用自己的话复述一遍。',
    reason: '理解类任务需要一段连续思考时间，推荐 35 分钟。',
  },
  {
    keywords: ['写作', '作文', '论文', '创作', '设计', '画画', '编程', '项目', '策划', '报告'],
    taskType: '创作',
    recommendedMinutes: 50,
    recommendedBreakMinutes: 10,
    recommendedNoise: 'cafe',
    advice: '创作前先列出大纲，先完成再完美，避免过早陷入细节。',
    reason: '创作类任务进入心流需要较长时间，推荐 50 分钟。',
  },
  {
    keywords: ['做题', '刷题', '练习', '试卷', '题库', '考试', '习题', '计算'],
    taskType: '刷题',
    recommendedMinutes: 45,
    recommendedBreakMinutes: 8,
    recommendedNoise: 'ocean',
    advice: '刷题后务必总结错题，找到自己的知识盲区并针对性补强。',
    reason: '刷题任务需要保持题感和节奏，推荐 45 分钟。',
  },
];

export const DEFAULT_RESULT: AnalysisResult = {
  taskType: '其他',
  recommendedMinutes: 25,
  recommendedBreakMinutes: 5,
  recommendedNoise: 'forest',
  advice: '保持专注，遇到困难的任务可以尝试拆分为更小的子任务。',
  reason: '未识别到明确类型，按默认 25 分钟番茄钟处理。',
  source: 'local',
};

function getRecommendedNoise(taskType: TaskType): NoiseType {
  const map: Record<TaskType, NoiseType> = {
    '记忆': 'rain',
    '理解': 'library',
    '创作': 'cafe',
    '刷题': 'ocean',
    '其他': 'forest',
  };
  return map[taskType];
}

export function analyzeTaskLocally(task: string): AnalysisResult {
  const lowerTask = task.toLowerCase();
  for (const rule of RULES) {
    const matched = rule.keywords.some((keyword) => lowerTask.includes(keyword.toLowerCase()));
    if (matched) {
      return {
        taskType: rule.taskType,
        recommendedMinutes: rule.recommendedMinutes,
        recommendedBreakMinutes: rule.recommendedBreakMinutes,
        recommendedNoise: rule.recommendedNoise,
        advice: rule.advice,
        reason: rule.reason,
        source: 'local',
      };
    }
  }
  return DEFAULT_RESULT;
}

function buildSystemPrompt(): string {
  return `你是一个学习专注助手。请根据用户输入的学习任务，分析任务类型并给出专注建议。
只能从以下任务类型中选择：记忆、理解、创作、刷题、其他。
白噪音类型只能从以下选择：rain（雨声）、cafe（咖啡厅）、library（图书馆）、forest（森林）、ocean（海浪）、fire（篝火）、wind（风声）、night（夜虫）、stream（溪流）、train（火车）。
请严格返回 JSON 格式，不要包含任何其他内容。字段说明：taskType 为任务类型；recommendedMinutes 为推荐专注分钟数（5-120）；breakMinutes / recommendedBreakMinutes 为推荐休息分钟数；recommendedNoise 为推荐白噪音；suggestion / advice 为一句中文学习建议；reason 为简短分析原因。
{
  "taskType": "...",
  "recommendedMinutes": number,
  "breakMinutes": number,
  "recommendedNoise": "rain|cafe|library|forest|ocean|fire|wind|night|stream|train",
  "suggestion": "一句中文学习建议",
  "reason": "简短分析原因"
}`;
}

function isValidNoise(noise: string): noise is NoiseType {
  return ['rain', 'cafe', 'library', 'forest', 'ocean', 'fire', 'wind', 'night', 'stream', 'train'].includes(noise);
}

function isValidTaskType(type: string): type is TaskType {
  return ['记忆', '理解', '创作', '刷题', '其他'].includes(type);
}

function normalizeAIResult(parsed: Partial<AnalysisResult>, source: AnalysisSource): AnalysisResult {
  const taskType = parsed.taskType && isValidTaskType(parsed.taskType) ? parsed.taskType : '其他';
  const recommendedMinutes = Math.max(5, Math.min(120, Number(parsed.recommendedMinutes) || 25));
  const recommendedBreakMinutes = Math.max(
    1,
    Math.min(30, Number(parsed.recommendedBreakMinutes) || 5)
  );
  const recommendedNoise = parsed.recommendedNoise && isValidNoise(parsed.recommendedNoise)
    ? parsed.recommendedNoise
    : getRecommendedNoise(taskType);
  const advice = parsed.advice?.trim() || DEFAULT_RESULT.advice;
  const reason = parsed.reason?.trim() || DEFAULT_RESULT.reason;

  return {
    taskType,
    recommendedMinutes,
    recommendedBreakMinutes,
    recommendedNoise,
    advice,
    reason,
    source,
  };
}

export async function analyzeTaskWithAI(task: string, settings: AISettings): Promise<AnalysisResult> {
  if (!settings.enabled || !settings.apiKey) {
    return analyzeTaskLocally(task);
  }

  try {
    const response = await fetch(`${settings.baseUrl.replace(/\/$/, '')}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${settings.apiKey}`,
      },
      body: JSON.stringify({
        model: settings.model,
        messages: [
          { role: 'system', content: buildSystemPrompt() },
          { role: 'user', content: task },
        ],
        temperature: 0.3,
      }),
    });

    if (!response.ok) {
      console.warn('AI 接口请求失败，回退到本地规则:', response.status, await response.text().catch(() => ''));
      return analyzeTaskLocally(task);
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content || '';
    const match = content.match(/\{[\s\S]*\}/);
    if (!match) {
      return analyzeTaskLocally(task);
    }

    const parsedRaw = JSON.parse(match[0]) as Record<string, unknown>;
    // 兼容 AI 可能返回的别名字段
    const parsed: Partial<AnalysisResult> = {
      taskType: parsedRaw.taskType as TaskType | undefined,
      recommendedMinutes: Number(parsedRaw.recommendedMinutes),
      recommendedBreakMinutes: Number(parsedRaw.recommendedBreakMinutes ?? parsedRaw.breakMinutes),
      recommendedNoise: (parsedRaw.recommendedNoise as NoiseType) || undefined,
      advice: (parsedRaw.advice as string) || (parsedRaw.suggestion as string) || undefined,
      reason: (parsedRaw.reason as string) || undefined,
    };
    return normalizeAIResult(parsed, 'ai');
  } catch (error) {
    console.error('AI 分析失败，回退到本地规则:', error);
    return analyzeTaskLocally(task);
  }
}

export function analyzeTask(task: string, useAI: boolean, settings: AISettings): Promise<AnalysisResult> {
  return useAI ? analyzeTaskWithAI(task, settings) : Promise.resolve(analyzeTaskLocally(task));
}
