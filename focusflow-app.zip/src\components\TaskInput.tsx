import { useState } from 'react';
import { Sparkles, ArrowRight, Wand2 } from 'lucide-react';

interface TaskInputProps {
  onAnalyze: (task: string, useAI: boolean) => void;
  loading: boolean;
  aiEnabled: boolean;
}

export function TaskInput({ onAnalyze, loading, aiEnabled }: TaskInputProps) {
  const [task, setTask] = useState('');
  const [useAI, setUseAI] = useState(aiEnabled);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!task.trim() || loading) return;
    onAnalyze(task.trim(), useAI);
  };

  const quickTasks = [
    '背诵 50 个英语单词',
    '阅读《深入理解计算机系统》一章',
    '完成前端项目登录页面',
    '刷 30 道算法题',
  ];

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="relative">
        <label htmlFor="task" className="mb-2 block text-sm font-semibold text-surface-700 dark:text-surface-300">
          今天想专注完成什么学习任务？
        </label>
        <textarea
          id="task"
          rows={4}
          value={task}
          onChange={(e) => setTask(e.target.value)}
          placeholder="例如：背诵 50 个英语单词、阅读《深入理解计算机系统》..."
          className="input-field resize-none text-base"
        />
        <div className="absolute bottom-3 right-3 text-xs text-surface-400">
          {task.length} 字
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        {quickTasks.map((t) => (
          <button
            key={t}
            type="button"
            onClick={() => setTask(t)}
            className="rounded-full border border-surface-200 bg-surface-50 px-3 py-1.5 text-xs font-medium text-surface-600 transition hover:border-primary-300 hover:bg-primary-50 hover:text-primary-700 dark:border-surface-800 dark:bg-surface-900 dark:text-surface-400 dark:hover:border-primary-700 dark:hover:bg-primary-900/20 dark:hover:text-primary-300"
          >
            {t}
          </button>
        ))}
      </div>

      <div className="flex items-center justify-between rounded-2xl border border-surface-200 bg-surface-50 p-4 dark:border-surface-800 dark:bg-surface-900">
        <label className="flex cursor-pointer items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-yellow-400 to-orange-400 text-white shadow">
            <Sparkles className="h-5 w-5" />
          </div>
          <div>
            <p className="text-sm font-semibold text-surface-900 dark:text-white">启用 AI 智能分析</p>
            <p className="text-xs text-surface-500 dark:text-surface-400">
              {aiEnabled ? '已配置 API，将使用大模型分析' : '未配置 API，将使用本地规则分析'}
            </p>
          </div>
          <input
            type="checkbox"
            checked={useAI}
            onChange={(e) => setUseAI(e.target.checked)}
            className="ml-3 h-5 w-5 rounded border-surface-300 text-primary-600 focus:ring-primary-500 dark:border-surface-700"
          />
        </label>
      </div>

      <button
        type="submit"
        disabled={!task.trim() || loading}
        className="btn-primary w-full py-4 text-base"
      >
        {loading ? (
          <>
            <Wand2 className="h-5 w-5 animate-spin" />
            AI 分析中...
          </>
        ) : (
          <>
            分析任务
            <ArrowRight className="h-5 w-5" />
          </>
        )}
      </button>
    </form>
  );
}
