import { AnalysisResult as AnalysisResultType } from '../types';
import { Clock, Lightbulb, Play, RotateCcw, Sparkles, Cpu } from 'lucide-react';
import { NOISE_OPTIONS } from '../utils/whiteNoise';

interface AnalysisResultProps {
  result: AnalysisResultType;
  onStart: () => void;
  onReset: () => void;
}

export function AnalysisResultView({ result, onStart, onReset }: AnalysisResultProps) {
  const noiseOption = NOISE_OPTIONS.find((n) => n.id === result.recommendedNoise);
  const isAI = result.source === 'ai';

  return (
    <div className="glass-card p-6 sm:p-8 animate-scale-in">
      <div className="mb-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary-100 text-primary-600 dark:bg-primary-900/30 dark:text-primary-400">
            <Sparkles className="h-5 w-5" />
          </div>
          <h3 className="section-title">AI 分析结果</h3>
        </div>
        <span
          className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold ${
            isAI
              ? 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300'
              : 'bg-surface-100 text-surface-600 dark:bg-surface-800 dark:text-surface-300'
          }`}
        >
          {isAI ? <Sparkles className="h-3 w-3" /> : <Cpu className="h-3 w-3" />}
          {isAI ? 'AI 分析' : '本地规则'}
        </span>
      </div>

      <div className="mb-6 grid grid-cols-2 gap-4 sm:grid-cols-4">
        <div className="rounded-2xl bg-surface-50 p-4 text-center transition hover:bg-surface-100 dark:bg-surface-800/50 dark:hover:bg-surface-800">
          <p className="mb-1 text-xs text-surface-500 dark:text-surface-400">任务类型</p>
          <p className="text-2xl font-bold text-surface-900 dark:text-white">{result.taskType}</p>
        </div>
        <div className="rounded-2xl bg-surface-50 p-4 text-center transition hover:bg-surface-100 dark:bg-surface-800/50 dark:hover:bg-surface-800">
          <p className="mb-1 text-xs text-surface-500 dark:text-surface-400">推荐专注</p>
          <p className="text-2xl font-bold text-primary-600 dark:text-primary-400">
            {result.recommendedMinutes}
            <span className="ml-1 text-sm font-medium text-surface-500">分钟</span>
          </p>
        </div>
        <div className="rounded-2xl bg-surface-50 p-4 text-center transition hover:bg-surface-100 dark:bg-surface-800/50 dark:hover:bg-surface-800">
          <p className="mb-1 text-xs text-surface-500 dark:text-surface-400">推荐休息</p>
          <p className="text-2xl font-bold text-accent-600 dark:text-accent-400">
            {result.recommendedBreakMinutes}
            <span className="ml-1 text-sm font-medium text-surface-500">分钟</span>
          </p>
        </div>
        <div className="rounded-2xl bg-surface-50 p-4 text-center transition hover:bg-surface-100 dark:bg-surface-800/50 dark:hover:bg-surface-800">
          <p className="mb-1 text-xs text-surface-500 dark:text-surface-400">推荐白噪音</p>
          <p className="text-lg font-bold text-surface-900 dark:text-white">
            {noiseOption?.icon} {noiseOption?.name}
          </p>
        </div>
      </div>

      <div className="mb-4 flex items-start gap-3 rounded-2xl bg-primary-50 p-4 dark:bg-primary-900/20">
        <Lightbulb className="mt-0.5 h-5 w-5 flex-shrink-0 text-primary-500" />
        <div>
          <p className="text-sm font-semibold text-primary-800 dark:text-primary-200">学习建议</p>
          <p className="text-sm text-primary-700 dark:text-primary-300">{result.advice}</p>
        </div>
      </div>

      <div className="mb-6 flex items-start gap-3 rounded-2xl border border-surface-200 bg-white p-4 dark:border-surface-800 dark:bg-surface-900">
        <Clock className="mt-0.5 h-5 w-5 flex-shrink-0 text-surface-400" />
        <div className="flex-1">
          <p className="text-sm font-semibold text-surface-800 dark:text-surface-200">分析原因</p>
          <p className="text-sm text-surface-700 dark:text-surface-300">{result.reason}</p>
        </div>
      </div>

      <div className="flex flex-col gap-3 sm:flex-row">
        <button onClick={onStart} className="btn-primary flex-1 py-4 ripple">
          <Play className="h-5 w-5" />
          开始专注
        </button>
        <button onClick={onReset} className="btn-secondary py-4 ripple">
          <RotateCcw className="h-5 w-5" />
          重新输入
        </button>
      </div>
    </div>
  );
}
