import { NoiseType } from '../types';

export const NOISE_OPTIONS: { id: NoiseType; name: string; icon: string; description: string }[] = [
  { id: 'rain', name: '雨声', icon: '🌧️', description: '细雨淅沥，适合深度思考' },
  { id: 'cafe', name: '咖啡厅', icon: '☕', description: '轻柔人声与杯盘碰撞' },
  { id: 'library', name: '图书馆', icon: '📚', description: '安静翻页与空调底噪' },
  { id: 'forest', name: '森林', icon: '🌲', description: '鸟鸣与微风，舒缓焦虑' },
  { id: 'ocean', name: '海浪', icon: '🌊', description: '节律海浪，帮助进入心流' },
  { id: 'fire', name: '篝火', icon: '🔥', description: '温暖噼啪声，安抚情绪' },
  { id: 'wind', name: '风声', icon: '🍃', description: '徐徐风声，营造开阔感' },
  { id: 'night', name: '夜虫', icon: '🦗', description: '夏夜虫鸣，助眠又专注' },
  { id: 'stream', name: '溪流', icon: '💧', description: '潺潺流水，清新自然' },
  { id: 'train', name: '火车', icon: '🚃', description: '规律轨道声，稳定节奏' },
];

export class WhiteNoiseEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private sources: AudioNode[] = [];
  private isPlaying = false;
  private currentType: NoiseType | null = null;
  private volume = 0.5;

  private getContext(): AudioContext {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    }
    return this.ctx;
  }

  private createNoiseBuffer(): AudioBuffer {
    const ctx = this.getContext();
    const sampleRate = ctx.sampleRate;
    const bufferSize = sampleRate * 2;
    const buffer = ctx.createBuffer(1, bufferSize, sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }
    return buffer;
  }

  private createNoiseSource(filterType: BiquadFilterType, frequency: number, gain: number): AudioNode {
    const ctx = this.getContext();
    const buffer = this.createNoiseBuffer();
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.loop = true;

    const filter = ctx.createBiquadFilter();
    filter.type = filterType;
    filter.frequency.value = frequency;

    const gainNode = ctx.createGain();
    gainNode.gain.value = gain;

    source.connect(filter);
    filter.connect(gainNode);
    source.start();
    this.sources.push(source);
    return gainNode;
  }

  private createOscillator(type: OscillatorType, frequency: number, gain: number): AudioNode {
    const ctx = this.getContext();
    const osc = ctx.createOscillator();
    osc.type = type;
    osc.frequency.value = frequency;

    const gainNode = ctx.createGain();
    gainNode.gain.value = gain;

    osc.connect(gainNode);
    osc.start();
    this.sources.push(osc);
    return gainNode;
  }

  private createCrackles(rate: number, gain: number): AudioNode {
    const ctx = this.getContext();
    const gainNode = ctx.createGain();
    gainNode.gain.value = gain;

    const schedule = () => {
      if (!this.isPlaying) return;
      const now = ctx.currentTime;
      const noise = ctx.createBufferSource();
      const len = ctx.sampleRate * 0.015;
      const buffer = ctx.createBuffer(1, len, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < len; i++) {
        data[i] = Math.random() * 2 - 1;
      }
      noise.buffer = buffer;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0, now);
      g.gain.linearRampToValueAtTime(Math.random() * 0.8 + 0.2, now + 0.005);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
      noise.connect(g);
      g.connect(gainNode);
      noise.start(now);
      this.sources.push(noise, g);
      setTimeout(schedule, (Math.random() * 1000) / rate + 50);
    };
    schedule();
    return gainNode;
  }

  private createChirps(gain: number): AudioNode {
    const ctx = this.getContext();
    const gainNode = ctx.createGain();
    gainNode.gain.value = gain;

    const chirp = () => {
      if (!this.isPlaying) return;
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      osc.type = 'sine';
      const startFreq = 2500 + Math.random() * 1500;
      osc.frequency.setValueAtTime(startFreq, now);
      osc.frequency.exponentialRampToValueAtTime(startFreq * 0.7, now + 0.08);
      const g = ctx.createGain();
      g.gain.setValueAtTime(0, now);
      g.gain.linearRampToValueAtTime(0.6, now + 0.02);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
      osc.connect(g);
      g.connect(gainNode);
      osc.start(now);
      osc.stop(now + 0.2);
      this.sources.push(osc, g);
      setTimeout(chirp, Math.random() * 3000 + 800);
    };
    chirp();
    return gainNode;
  }

  private createWind(gain: number): AudioNode {
    const ctx = this.getContext();
    const buffer = this.createNoiseBuffer();
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.loop = true;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value = 400;
    filter.Q.value = 0.5;

    const gainNode = ctx.createGain();
    gainNode.gain.value = gain;

    // modulate filter frequency for gust effect
    const lfo = ctx.createOscillator();
    lfo.type = 'sine';
    lfo.frequency.value = 0.2;
    const lfoGain = ctx.createGain();
    lfoGain.gain.value = 250;
    lfo.connect(lfoGain);
    lfoGain.connect(filter.frequency);
    lfo.start();

    source.connect(filter);
    filter.connect(gainNode);
    source.start();
    this.sources.push(source, lfo, lfoGain);
    return gainNode;
  }

  private createWave(gain: number): AudioNode {
    const ctx = this.getContext();
    const buffer = this.createNoiseBuffer();
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.loop = true;

    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 300;

    const gainNode = ctx.createGain();
    gainNode.gain.value = gain;

    const lfo = ctx.createOscillator();
    lfo.type = 'sine';
    lfo.frequency.value = 0.12;
    const lfoGain = ctx.createGain();
    lfoGain.gain.value = 200;
    lfo.connect(lfoGain);
    lfoGain.connect(filter.frequency);
    lfo.start();

    source.connect(filter);
    filter.connect(gainNode);
    source.start();
    this.sources.push(source, lfo, lfoGain);
    return gainNode;
  }

  private buildNoise(type: NoiseType): AudioNode {
    const ctx = this.getContext();
    const mix = ctx.createGain();
    mix.gain.value = 1;

    switch (type) {
      case 'rain': {
        const rain = this.createNoiseSource('lowpass', 800, 0.6);
        const hiss = this.createNoiseSource('bandpass', 3000, 0.15);
        rain.connect(mix);
        hiss.connect(mix);
        break;
      }
      case 'cafe': {
        const murmur = this.createNoiseSource('bandpass', 400, 0.5);
        const clink = this.createNoiseSource('highpass', 2000, 0.08);
        const bass = this.createNoiseSource('lowpass', 200, 0.2);
        murmur.connect(mix);
        clink.connect(mix);
        bass.connect(mix);
        break;
      }
      case 'library': {
        const room = this.createNoiseSource('lowpass', 600, 0.4);
        const page = this.createNoiseSource('highpass', 1500, 0.05);
        const hum = this.createOscillator('sine', 60, 0.03);
        room.connect(mix);
        page.connect(mix);
        hum.connect(mix);
        break;
      }
      case 'forest': {
        const wind = this.createNoiseSource('lowpass', 300, 0.3);
        const rustle = this.createNoiseSource('bandpass', 1200, 0.1);
        const chirp = this.createChirps(0.08);
        chirp.connect(mix);
        wind.connect(mix);
        rustle.connect(mix);
        break;
      }
      case 'ocean': {
        const wave = this.createWave(0.55);
        const foam = this.createNoiseSource('bandpass', 900, 0.12);
        wave.connect(mix);
        foam.connect(mix);
        break;
      }
      case 'fire': {
        const base = this.createNoiseSource('lowpass', 500, 0.35);
        const crackle = this.createCrackles(1.2, 0.4);
        base.connect(mix);
        crackle.connect(mix);
        break;
      }
      case 'wind': {
        const wind = this.createWind(0.5);
        const leaf = this.createNoiseSource('highpass', 2500, 0.04);
        wind.connect(mix);
        leaf.connect(mix);
        break;
      }
      case 'night': {
        const cricket = this.createChirps(0.12);
        const ambience = this.createNoiseSource('lowpass', 200, 0.08);
        cricket.connect(mix);
        ambience.connect(mix);
        break;
      }
      case 'stream': {
        const flow = this.createNoiseSource('bandpass', 700, 0.45);
        const bubble = this.createNoiseSource('highpass', 3500, 0.08);
        flow.connect(mix);
        bubble.connect(mix);
        break;
      }
      case 'train': {
        const rumble = this.createNoiseSource('lowpass', 250, 0.45);
        const wheel = this.createOscillator('sine', 80, 0.05);
        const click = this.createCrackles(2.5, 0.15);
        rumble.connect(mix);
        wheel.connect(mix);
        click.connect(mix);
        break;
      }
    }

    return mix;
  }

  async play(type: NoiseType): Promise<void> {
    const ctx = this.getContext();
    if (ctx.state === 'suspended') {
      await ctx.resume();
    }

    if (this.isPlaying && this.currentType === type) return;

    this.stop();
    this.masterGain = ctx.createGain();
    this.masterGain.gain.value = this.volume;
    this.masterGain.connect(ctx.destination);

    const mix = this.buildNoise(type);
    mix.connect(this.masterGain);

    this.currentType = type;
    this.isPlaying = true;
  }

  stop(): void {
    this.sources.forEach((source) => {
      try {
        if ((source as OscillatorNode).stop) {
          (source as OscillatorNode).stop();
        }
        if ((source as AudioBufferSourceNode).stop) {
          (source as AudioBufferSourceNode).stop();
        }
      } catch {
        // ignore
      }
    });
    this.sources = [];
    if (this.masterGain) {
      this.masterGain.disconnect();
      this.masterGain = null;
    }
    this.isPlaying = false;
    this.currentType = null;
  }

  fadeOut(duration = 2000): Promise<void> {
    return new Promise((resolve) => {
      if (!this.masterGain || !this.isPlaying) {
        this.stop();
        resolve();
        return;
      }
      const ctx = this.getContext();
      const now = ctx.currentTime;
      this.masterGain.gain.setValueAtTime(this.masterGain.gain.value, now);
      this.masterGain.gain.exponentialRampToValueAtTime(0.001, now + duration / 1000);
      setTimeout(() => {
        this.stop();
        resolve();
      }, duration);
    });
  }

  setVolume(value: number): void {
    this.volume = Math.max(0, Math.min(1, value));
    if (this.masterGain) {
      this.masterGain.gain.value = this.volume;
    }
  }

  getVolume(): number {
    return this.volume;
  }

  getCurrentType(): NoiseType | null {
    return this.currentType;
  }

  getIsPlaying(): boolean {
    return this.isPlaying;
  }
}

export const noiseEngine = new WhiteNoiseEngine();

// Sound effects engine for timer events
export class SoundEffectEngine {
  private ctx: AudioContext | null = null;
  private enabled = true;

  private getContext(): AudioContext {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    }
    return this.ctx;
  }

  setEnabled(enabled: boolean): void {
    this.enabled = enabled;
  }

  getEnabled(): boolean {
    return this.enabled;
  }

  private async ensureReady(): Promise<void> {
    const ctx = this.getContext();
    if (ctx.state === 'suspended') {
      await ctx.resume();
    }
  }

  private beep(frequency: number, duration: number, type: OscillatorType = 'sine', when?: number): void {
    if (!this.enabled) return;
    const ctx = this.getContext();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(frequency, when ?? ctx.currentTime);
    gain.gain.setValueAtTime(0.3, when ?? ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, (when ?? ctx.currentTime) + duration);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(when ?? ctx.currentTime);
    osc.stop((when ?? ctx.currentTime) + duration);
  }

  async playStart(): Promise<void> {
    if (!this.enabled) return;
    await this.ensureReady();
    const ctx = this.getContext();
    const now = ctx.currentTime;
    this.beep(523, 0.12, 'sine', now);
    this.beep(659, 0.12, 'sine', now + 0.12);
    this.beep(784, 0.2, 'sine', now + 0.24);
  }

  async playComplete(): Promise<void> {
    if (!this.enabled) return;
    await this.ensureReady();
    const ctx = this.getContext();
    const now = ctx.currentTime;
    this.beep(784, 0.12, 'sine', now);
    this.beep(988, 0.12, 'sine', now + 0.12);
    this.beep(1319, 0.35, 'sine', now + 0.24);
  }

  async playBreakReminder(): Promise<void> {
    if (!this.enabled) return;
    await this.ensureReady();
    const ctx = this.getContext();
    const now = ctx.currentTime;
    this.beep(440, 0.12, 'sine', now);
    this.beep(440, 0.12, 'sine', now + 0.18);
  }
}

export const soundEffects = new SoundEffectEngine();
